
This is the README file for the project.

I started this project when procrastinating.

I was playing this game called “Fire Emblem”. You can click on an
avatar, and the system is going to tell you where you can go. Moving on
the plain is faster than moving in the forest. Mountains are impassable.
Then I realized that I could actually try to implement this algorithm
with the knowledge I had learned in this semester!

After some research, I decided to implement this A\* algorithm by
Python.

A\* algorithm is like an ‘upgrade’ of Dijkstra’s algorithm. It
calculates not only the cost on the route, but also the “heuristic”, the
expected cost to the goal.

Among all the path-finding algorithms, A\* is one of the fastest. It’s
usually faster than Dijkstra, and better than greedy. It always returns
the optimal results.

It searches a way smaller area than Dijkstra does, when the location of
the goal is known. However, when the location of the goal is unknown, we
should still use Dijkstra to do the “blind search”.

Relevant Knowledge from CS110: Heaps, Greedy, Dynamic Programming, and
Optimal Algorithm. Details can be found in the code.

There are three examples with pictures. The code was attached and
included in the package.
